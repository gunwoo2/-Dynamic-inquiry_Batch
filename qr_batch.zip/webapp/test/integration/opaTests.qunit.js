/* global QUnit */

sap.ui.require(["sync/ea/qrbatch/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
