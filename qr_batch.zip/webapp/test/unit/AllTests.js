sap.ui.define([
	"syncea/qr_batch/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
